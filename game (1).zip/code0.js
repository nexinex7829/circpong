gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final = [];

gdjs.Untitled_32sceneCode.GDboardObjects1= [];
gdjs.Untitled_32sceneCode.GDboardObjects2= [];
gdjs.Untitled_32sceneCode.GDboardObjects3= [];
gdjs.Untitled_32sceneCode.GDboardObjects4= [];
gdjs.Untitled_32sceneCode.GDboardObjects5= [];
gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects1= [];
gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects2= [];
gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects3= [];
gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects4= [];
gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects5= [];
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1= [];
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2= [];
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects3= [];
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects4= [];
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects5= [];
gdjs.Untitled_32sceneCode.GDscoreObjects1= [];
gdjs.Untitled_32sceneCode.GDscoreObjects2= [];
gdjs.Untitled_32sceneCode.GDscoreObjects3= [];
gdjs.Untitled_32sceneCode.GDscoreObjects4= [];
gdjs.Untitled_32sceneCode.GDscoreObjects5= [];
gdjs.Untitled_32sceneCode.GDStarBronzeObjects1= [];
gdjs.Untitled_32sceneCode.GDStarBronzeObjects2= [];
gdjs.Untitled_32sceneCode.GDStarBronzeObjects3= [];
gdjs.Untitled_32sceneCode.GDStarBronzeObjects4= [];
gdjs.Untitled_32sceneCode.GDStarBronzeObjects5= [];
gdjs.Untitled_32sceneCode.GDpopupScoreObjects1= [];
gdjs.Untitled_32sceneCode.GDpopupScoreObjects2= [];
gdjs.Untitled_32sceneCode.GDpopupScoreObjects3= [];
gdjs.Untitled_32sceneCode.GDpopupScoreObjects4= [];
gdjs.Untitled_32sceneCode.GDpopupScoreObjects5= [];
gdjs.Untitled_32sceneCode.GDhighScoreObjects1= [];
gdjs.Untitled_32sceneCode.GDhighScoreObjects2= [];
gdjs.Untitled_32sceneCode.GDhighScoreObjects3= [];
gdjs.Untitled_32sceneCode.GDhighScoreObjects4= [];
gdjs.Untitled_32sceneCode.GDhighScoreObjects5= [];
gdjs.Untitled_32sceneCode.GDGreyButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDGreyButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDGreyButtonObjects3= [];
gdjs.Untitled_32sceneCode.GDGreyButtonObjects4= [];
gdjs.Untitled_32sceneCode.GDGreyButtonObjects5= [];
gdjs.Untitled_32sceneCode.GDNewShapePainterObjects1= [];
gdjs.Untitled_32sceneCode.GDNewShapePainterObjects2= [];
gdjs.Untitled_32sceneCode.GDNewShapePainterObjects3= [];
gdjs.Untitled_32sceneCode.GDNewShapePainterObjects4= [];
gdjs.Untitled_32sceneCode.GDNewShapePainterObjects5= [];
gdjs.Untitled_32sceneCode.GDInstructionsObjects1= [];
gdjs.Untitled_32sceneCode.GDInstructionsObjects2= [];
gdjs.Untitled_32sceneCode.GDInstructionsObjects3= [];
gdjs.Untitled_32sceneCode.GDInstructionsObjects4= [];
gdjs.Untitled_32sceneCode.GDInstructionsObjects5= [];


gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDboardObjects4Objects = Hashtable.newFrom({"board": gdjs.Untitled_32sceneCode.GDboardObjects4});
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))), false);
if (isConditionTrue_0) {
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))), true);
if (isConditionTrue_0) {
gdjs.Untitled_32sceneCode.GDboardObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDboardObjects4Objects, -(400), -(400), "underLayer");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDboardObjects4.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDboardObjects4[i].returnVariable(gdjs.Untitled_32sceneCode.GDboardObjects4[i].getVariables().getFromIndex(0)).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)));
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("board"), gdjs.Untitled_32sceneCode.GDboardObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDboardObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDboardObjects3[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDboardObjects3[i].getVariables().getFromIndex(0)) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDboardObjects3[k] = gdjs.Untitled_32sceneCode.GDboardObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDboardObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DirectionalArrowFullCircle"), gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects3);
/* Reuse gdjs.Untitled_32sceneCode.GDboardObjects3 */
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))).add(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))).getAsNumber());
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDboardObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDboardObjects3[i].putAroundObject((gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects3.length !== 0 ? gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects3[0] : null), runtimeScene.getScene().getVariables().getFromIndex(2).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(0).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))).getAsNumber());
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDboardObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDboardObjects3[i].rotateTowardAngle(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))).getAsNumber(), 0, runtimeScene);
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList2 = function(runtimeScene) {

{


const repeatCount3 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0));
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {

let isConditionTrue_0 = false;
if (true)
{
{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}
{ //Subevents: 
gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(-(1));
}}

}


{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {

let isConditionTrue_0 = false;
if (true)
{
{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}
{ //Subevents: 
gdjs.Untitled_32sceneCode.eventsList1(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Untitled_32sceneCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("board"), gdjs.Untitled_32sceneCode.GDboardObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDboardObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDboardObjects3[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDboardObjects3[i].getVariables().getFromIndex(0)) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDboardObjects3[k] = gdjs.Untitled_32sceneCode.GDboardObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDboardObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DirectionalArrowFullCircle"), gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects3);
/* Reuse gdjs.Untitled_32sceneCode.GDboardObjects3 */
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))).add(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))).getAsNumber());
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDboardObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDboardObjects3[i].putAroundObject((gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects3.length !== 0 ? gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects3[0] : null), runtimeScene.getScene().getVariables().getFromIndex(2).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(0).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))).getAsNumber());
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDboardObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDboardObjects3[i].rotateTowardAngle(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))).getAsNumber(), 0, runtimeScene);
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList4 = function(runtimeScene) {

{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {

let isConditionTrue_0 = false;
if (true)
{
{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}
{ //Subevents: 
gdjs.Untitled_32sceneCode.eventsList3(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Untitled_32sceneCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("board"), gdjs.Untitled_32sceneCode.GDboardObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDboardObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDboardObjects3[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDboardObjects3[i].getVariables().getFromIndex(0)) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDboardObjects3[k] = gdjs.Untitled_32sceneCode.GDboardObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDboardObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DirectionalArrowFullCircle"), gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects3);
/* Reuse gdjs.Untitled_32sceneCode.GDboardObjects3 */
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))).sub(runtimeScene.getScene().getVariables().getFromIndex(1).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))).getAsNumber());
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDboardObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDboardObjects3[i].putAroundObject((gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects3.length !== 0 ? gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects3[0] : null), runtimeScene.getScene().getVariables().getFromIndex(2).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(0).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))).getAsNumber());
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDboardObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDboardObjects3[i].rotateTowardAngle(runtimeScene.getScene().getVariables().getFromIndex(0).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))).getAsNumber(), 0, runtimeScene);
}
}}

}


};gdjs.Untitled_32sceneCode.eventsList6 = function(runtimeScene) {

{


const repeatCount2 = gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().getFromIndex(0));
for (let repeatIndex2 = 0;repeatIndex2 < repeatCount2;++repeatIndex2) {

let isConditionTrue_0 = false;
if (true)
{
{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}
{ //Subevents: 
gdjs.Untitled_32sceneCode.eventsList5(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSmallBlueBallObjects1Objects = Hashtable.newFrom({"SmallBlueBall": gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDStarBronzeObjects1Objects = Hashtable.newFrom({"StarBronze": gdjs.Untitled_32sceneCode.GDStarBronzeObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDpopupScoreObjects1Objects = Hashtable.newFrom({"popupScore": gdjs.Untitled_32sceneCode.GDpopupScoreObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSmallBlueBallObjects1Objects = Hashtable.newFrom({"SmallBlueBall": gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDboardObjects1Objects = Hashtable.newFrom({"board": gdjs.Untitled_32sceneCode.GDboardObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSmallBlueBallObjects2Objects = Hashtable.newFrom({"SmallBlueBall": gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDStarBronzeObjects1Objects = Hashtable.newFrom({"StarBronze": gdjs.Untitled_32sceneCode.GDStarBronzeObjects1});
gdjs.Untitled_32sceneCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(11), false);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(9).setNumber(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) == gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)), 15) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5));
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1, gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSmallBlueBallObjects2Objects, 640, 340, "");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i].addPolarForce(gdjs.random(360), 150, 1);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("DirectionalArrowFullCircle"), gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects1);
gdjs.Untitled_32sceneCode.GDStarBronzeObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDStarBronzeObjects1Objects, 0, 0, "");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStarBronzeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStarBronzeObjects1[i].putAroundObject((gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects1.length !== 0 ? gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects1[0] : null), gdjs.random(300), gdjs.random(360));
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(11), false);
}}

}


};gdjs.Untitled_32sceneCode.eventsList8 = function(runtimeScene) {

{



}


{

/* Reuse gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1, gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2);

for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i].getVariables().getFromIndex(0)) > (gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i].getCenterXInScene()) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(13)) ) {
        isConditionTrue_1 = true;
        gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[k] = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.indexOf(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.push(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1, gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2);

for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i].getVariables().getFromIndex(0)) < (gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i].getCenterXInScene()) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(13)) ) {
        isConditionTrue_1 = true;
        gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[k] = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.indexOf(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.push(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1, gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2);

for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i].getVariables().getFromIndex(1)) > (gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i].getCenterYInScene()) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(13)) ) {
        isConditionTrue_1 = true;
        gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[k] = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.indexOf(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.push(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1, gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2);

for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i].getVariables().getFromIndex(1)) < (gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i].getCenterYInScene()) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(13)) ) {
        isConditionTrue_1 = true;
        gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[k] = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.indexOf(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.push(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final, gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "scoreTimeout") >= 0.12;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1 */
gdjs.copyArray(runtimeScene.getObjects("score"), gdjs.Untitled_32sceneCode.GDscoreObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(5).add(1 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(12)));
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDscoreObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDscoreObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString((( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1[0].getCenterXInScene())));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scoreTimeout");
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSmallBlueBallObjects1Objects = Hashtable.newFrom({"SmallBlueBall": gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDboardObjects1Objects = Hashtable.newFrom({"board": gdjs.Untitled_32sceneCode.GDboardObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDboardObjects1Objects = Hashtable.newFrom({"board": gdjs.Untitled_32sceneCode.GDboardObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSmallBlueBallObjects1Objects = Hashtable.newFrom({"SmallBlueBall": gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSmallBlueBallObjects1Objects = Hashtable.newFrom({"SmallBlueBall": gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1});
gdjs.Untitled_32sceneCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7)) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(8));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSmallBlueBallObjects1Objects) == 0;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("highScore"), gdjs.Untitled_32sceneCode.GDhighScoreObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(8)));
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDhighScoreObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDhighScoreObjects2[i].getBehavior("Text").setText("Highscore: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7))));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSmallBlueBallObjects1Objects) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Instructions"), gdjs.Untitled_32sceneCode.GDInstructionsObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewShapePainter"), gdjs.Untitled_32sceneCode.GDNewShapePainterObjects1);
/* Reuse gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1 */
gdjs.copyArray(runtimeScene.getObjects("StarBronze"), gdjs.Untitled_32sceneCode.GDStarBronzeObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(8).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(9).setNumber(1);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStarBronzeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStarBronzeObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewShapePainterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewShapePainterObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDInstructionsObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDInstructionsObjects1[i].hide(false);
}
}}

}


};gdjs.Untitled_32sceneCode.mapOfEmptyGDSmallBlueBallObjects = Hashtable.newFrom({"SmallBlueBall": []});
gdjs.Untitled_32sceneCode.eventsList10 = function(runtimeScene) {

{

/* Reuse gdjs.Untitled_32sceneCode.GDpopupScoreObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDpopupScoreObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDpopupScoreObjects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDpopupScoreObjects1[i].getVariables().getFromIndex(0)) > (gdjs.Untitled_32sceneCode.GDpopupScoreObjects1[i].getY()) + 100 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDpopupScoreObjects1[k] = gdjs.Untitled_32sceneCode.GDpopupScoreObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDpopupScoreObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDpopupScoreObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDpopupScoreObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDpopupScoreObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSmallBlueBallObjects1Objects = Hashtable.newFrom({"SmallBlueBall": gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1});
gdjs.Untitled_32sceneCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.playerAuthentication.displayAuthenticationBanner(runtimeScene);
}{gdjs.playerAuthentication.removeAuthenticationBanner(runtimeScene);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(-(1));
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scoreTimeout");
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(-(1));
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(-(1));
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SmallBlueBall"), gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("StarBronze"), gdjs.Untitled_32sceneCode.GDStarBronzeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSmallBlueBallObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDStarBronzeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDStarBronzeObjects1 */
gdjs.Untitled_32sceneCode.GDpopupScoreObjects1.length = 0;

{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(11), true);
}{runtimeScene.getScene().getVariables().getFromIndex(8).add(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(9)) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(12)));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDpopupScoreObjects1Objects, (( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1[0].getPointY("")), "UI");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDpopupScoreObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDpopupScoreObjects1[i].getBehavior("Text").setText("+" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(9)) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(12))));
}
}{runtimeScene.getScene().getVariables().getFromIndex(9).setNumber(Math.min(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(9)) + 1, 8));
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDStarBronzeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDStarBronzeObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDpopupScoreObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDpopupScoreObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDpopupScoreObjects1[i].getVariables().getFromIndex(0)).setNumber((( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDpopupScoreObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDpopupScoreObjects1[i].getBehavior("Scale").setScale(Math.min(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("scoreAmount")) + 1, 8));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SmallBlueBall"), gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("board"), gdjs.Untitled_32sceneCode.GDboardObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSmallBlueBallObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDboardObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SmallBlueBall"), gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("board"), gdjs.Untitled_32sceneCode.GDboardObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSmallBlueBallObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDboardObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDboardObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber((( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1[0].getAverageForce().getAngle()));
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1[i].addPolarForce(runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber(), Math.pow((gdjs.evtTools.common.log2(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) + 3) * 280), 0.83), 1);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1[i].getBehavior("Bounce").BounceOff(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDboardObjects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1[i].getVariables().getFromIndex(0)).setNumber((gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1[i].getCenterXInScene()));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1[i].getVariables().getFromIndex(1)).setNumber((gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1[i].getCenterYInScene()));
}
}}

}


{

gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("SmallBlueBall"), gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2);
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i].getCenterXInScene() < 0 ) {
        isConditionTrue_1 = true;
        gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[k] = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.indexOf(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.push(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("SmallBlueBall"), gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2);
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i].getCenterXInScene() > 1280 ) {
        isConditionTrue_1 = true;
        gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[k] = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.indexOf(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.push(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("SmallBlueBall"), gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2);
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i].getCenterYInScene() < 0 ) {
        isConditionTrue_1 = true;
        gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[k] = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.indexOf(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.push(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("SmallBlueBall"), gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2);
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i].getCenterYInScene() > 720 ) {
        isConditionTrue_1 = true;
        gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[k] = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.indexOf(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[j]) === -1 )
            gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final.push(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1_1final, gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList9(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewShapePainter"), gdjs.Untitled_32sceneCode.GDNewShapePainterObjects1);
gdjs.copyArray(runtimeScene.getObjects("popupScore"), gdjs.Untitled_32sceneCode.GDpopupScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("score"), gdjs.Untitled_32sceneCode.GDscoreObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDpopupScoreObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDpopupScoreObjects1[i].setOutline("130;255;0", 3);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDpopupScoreObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDpopupScoreObjects1[i].setY(gdjs.Untitled_32sceneCode.GDpopupScoreObjects1[i].getY() - (5));
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewShapePainterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewShapePainterObjects1[i].drawRectangle(0, 0, 2000, 2000);
}
}{runtimeScene.getScene().getVariables().getFromIndex(12).setNumber(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfEmptyGDSmallBlueBallObjects));
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDscoreObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDscoreObjects1[i].getBehavior("Text").setText("Score:" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(8))));
}
}
{ //Subevents
gdjs.Untitled_32sceneCode.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewShapePainter"), gdjs.Untitled_32sceneCode.GDNewShapePainterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDNewShapePainterObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDNewShapePainterObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDNewShapePainterObjects1[k] = gdjs.Untitled_32sceneCode.GDNewShapePainterObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDNewShapePainterObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Instructions"), gdjs.Untitled_32sceneCode.GDInstructionsObjects1);
/* Reuse gdjs.Untitled_32sceneCode.GDNewShapePainterObjects1 */
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDSmallBlueBallObjects1Objects, 640, 340, "");
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1[i].addPolarForce(20, Math.pow((gdjs.evtTools.common.log2(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) + 2) * 280), 0.83), 1);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewShapePainterObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewShapePainterObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDInstructionsObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDInstructionsObjects1[i].hide();
}
}}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDboardObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDboardObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDboardObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDboardObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDboardObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDDirectionalArrowFullCircleObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDSmallBlueBallObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDscoreObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDscoreObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDscoreObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDscoreObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDscoreObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDStarBronzeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStarBronzeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStarBronzeObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDStarBronzeObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDStarBronzeObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDpopupScoreObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDpopupScoreObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDpopupScoreObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDpopupScoreObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDpopupScoreObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDhighScoreObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDhighScoreObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDhighScoreObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDhighScoreObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDhighScoreObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDGreyButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGreyButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGreyButtonObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDGreyButtonObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDGreyButtonObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDNewShapePainterObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewShapePainterObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewShapePainterObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDNewShapePainterObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDNewShapePainterObjects5.length = 0;
gdjs.Untitled_32sceneCode.GDInstructionsObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDInstructionsObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDInstructionsObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDInstructionsObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDInstructionsObjects5.length = 0;

gdjs.Untitled_32sceneCode.eventsList11(runtimeScene);

return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
